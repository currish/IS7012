using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RecruitCatnandisv.Pages
{
    public class OurTeamcshtmlModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

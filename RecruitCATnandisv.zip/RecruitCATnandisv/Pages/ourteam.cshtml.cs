using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RecruitCatnandisv.Pages
{
    public class ourteamModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

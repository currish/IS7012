﻿namespace Class.Pages.class_diagram_and_scaffolding
{
    public class BankAccount
    {
        public int BankAccountID { get; set; }

        public int CurrentBalance { get; set; }

        public string Account_Name {get; set;}

        public List<AccountHolder>? AccountHolderID { get; set; }
    }
}

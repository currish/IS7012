﻿namespace RecruitCatnandisv_updated10_.Pages.model
{
    public class Job_title
    {
        public int Job_title_ID {get; set;}

        public string job_title { get; set; }

        public int min_salary { get; set; }

        public int max_salary { get; set; }

        public DateTime job_End_Date { get; set; }

        public bool Job_title_eligibility { get; set; }
    }
}

﻿using Microsoft.VisualBasic;

namespace RecruitCatnandisv_updated10_.Pages.model
{
    public class Candidate
    {
        public int CandidateID { get; set; }
        public string first_name { get; set; }

        public string last_name { get; set; }

        public int target_salary { get; set; }

        public DateAndTime Date {get; set;}  

        public string? Candidate_skills  { get; set; }
    }
}

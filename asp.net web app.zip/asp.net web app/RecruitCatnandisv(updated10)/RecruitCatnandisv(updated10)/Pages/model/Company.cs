﻿namespace RecruitCatnandisv_updated10_.Pages.model
{
    public class Company
    {
        public int CompanyId { get; set; }

        public string CompanyName { get; set; }
        
        public string PositionName { get; set; }

        public int min_salary { get; set; }

        public int max_salary { get; set; }

        public DateTime? optional_start_date { get; set; }

        public string location { get; set; }

        public DateTime? optional_End_date { get; set; }

    }
}

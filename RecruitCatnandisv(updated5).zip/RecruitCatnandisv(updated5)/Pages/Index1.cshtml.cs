using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RecruitCatnandisv_updated5_.Pages
{
    public class Index1Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}

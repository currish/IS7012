using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RecruitCatnandisv_updated5_.Pages
{
    public class ourteamModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}

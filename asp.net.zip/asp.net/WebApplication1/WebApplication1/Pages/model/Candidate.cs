﻿using Microsoft.VisualBasic;

namespace WebApplication1.Pages.model
{
    public class Candidate
    {
        public int CandidateID { get; set; }
        public string? first_name { get; set; }

        public string? last_name { get; set; }

        public int target_salary { get; set; }

        public DateFormat? Start_Date { get; set; }

        public string? Candidate_skills { get; set; }
    }
}

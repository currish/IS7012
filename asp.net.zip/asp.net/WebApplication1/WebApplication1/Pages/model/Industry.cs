﻿namespace WebApplication1.Pages.model
{
    public class Industry
    {
        public int IndustryID { get; set; }

        public string IndustryName { get; set; }

        public string? Industrytype { get; set; }

        public DateTime Industry_Start_Date { get; set; }
    }
}

﻿namespace WebApplication1.Pages.model
{
    public class Job_title
    {
        public int Job_titleID { get; set; }

        public string job_title { get; set; }

        public int min_salary { get; set; }

        public int max_salary { get; set; }

        public DateTime job_End_Date { get; set; }

        public bool Job_title_eligibility { get; set; }
    }
}

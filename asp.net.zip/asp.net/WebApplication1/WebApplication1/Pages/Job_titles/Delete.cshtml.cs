﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WebApplication1.Data;
using WebApplication1.Pages.model;

namespace WebApplication1.Pages.Job_titles
{
    public class DeleteModel : PageModel
    {
        private readonly WebApplication1.Data.WebApplication1Context _context;

        public DeleteModel(WebApplication1.Data.WebApplication1Context context)
        {
            _context = context;
        }

        [BindProperty]
      public Job_title Job_title { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null || _context.Job_title == null)
            {
                return NotFound();
            }

            var job_title = await _context.Job_title.FirstOrDefaultAsync(m => m.Job_titleID == id);

            if (job_title == null)
            {
                return NotFound();
            }
            else 
            {
                Job_title = job_title;
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null || _context.Job_title == null)
            {
                return NotFound();
            }
            var job_title = await _context.Job_title.FindAsync(id);

            if (job_title != null)
            {
                Job_title = job_title;
                _context.Job_title.Remove(Job_title);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("./Index");
        }
    }
}
